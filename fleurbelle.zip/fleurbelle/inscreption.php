<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FleurBelle – Inscription</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: rgb(255, 234, 247); padding-top: 100px; }
        .auth-container { max-width: 450px; margin: 40px auto; padding: 0 20px; }
        .auth-card { background: #fff; border-radius: 12px; padding: 35px 40px; box-shadow: 0 5px 20px rgba(0,0,0,.1); }
        .auth-card h2 { font-size: 2.2rem; color: #333; margin-bottom: 25px; text-align: center; }
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; font-size: 1.4rem; color: #555; margin-bottom: 6px; }
        .form-group input {
            width: 100%; padding: 11px 14px; border: 1px solid #ddd;
            border-radius: 8px; font-size: 1.5rem; box-sizing: border-box; transition: border-color .2s;
        }
        .form-group input:focus { border-color: var(--pink); }
        .btn-full { width: 100%; text-align: center; margin-top: 8px; font-size: 1.6rem; }
        .link-row { text-align: center; font-size: 1.4rem; margin-top: 15px; color: #555; }
        .link-row a { color: var(--pink); }
        .alert { padding: 12px; border-radius: 6px; font-size: 1.4rem; margin-bottom: 15px; text-align: center; }
        .alert-error { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
<header>
    <a href="acceuil.php" class="logo">FleurBelle <span>.</span></a>
    <div class="icons">
        <a href="acceuil.php"><i class="fas fa-home"></i> Home</a>
        <a href="affichage_panier.php"><i class="fas fa-shopping-cart"></i> Panier</a>
        <a href="user.php"><i class="fas fa-user"></i> Connexion</a>
    </div>
</header>

<div class="auth-container">
    <?php if (isset($_GET['error']) && $_GET['error'] === 'nom_pris'): ?>
        <div class="alert alert-error">Ce nom d'utilisateur est déjà pris. Choisissez-en un autre.</div>
    <?php endif; ?>
    <div class="auth-card">
        <h2><i class="fas fa-user-plus" style="color:var(--pink)"></i> Inscription</h2>
        <form action="traitement_inscription.php" method="post">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Nom d'utilisateur</label>
                <input type="text" name="username" placeholder="Choisissez un nom d'utilisateur" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Mot de passe</label>
                <input type="password" name="password" placeholder="Minimum 6 caractères" minlength="6" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-map-marker-alt"></i> Adresse de livraison</label>
                <input type="text" name="adresse" placeholder="Votre adresse complète" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email (optionnel)</label>
                <input type="email" name="email" placeholder="votre@email.com">
            </div>
            <button type="submit" class="btn btn-full">Créer mon compte</button>
        </form>
        <div class="link-row">
            Déjà un compte ? <a href="user.php">Se connecter</a>
        </div>
    </div>
</div>
</body>
</html>
