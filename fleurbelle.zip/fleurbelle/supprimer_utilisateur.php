<?php
require_once 'config.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: user.php"); exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"] ?? '');
    $password = trim($_POST["password"] ?? '');
    $id       = $_SESSION['id_utilisateur'];

    $conn = getConnexion();

    $stmt = $conn->prepare("SELECT id_utilisateur, mdp FROM utilisateur WHERE nom = ? AND id_utilisateur = ?");
    $stmt->bind_param("si", $username, $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $ok = password_verify($password, $row['mdp']) || ($password === $row['mdp']);

        if ($ok) {
            $stmtDel = $conn->prepare("DELETE FROM utilisateur WHERE id_utilisateur = ?");
            $stmtDel->bind_param("i", $id);
            $stmtDel->execute();
            $stmtDel->close();

            $stmt->close();
            $conn->close();

            session_unset();
            session_destroy();
            header("Location: user.php?msg=supprime");
            exit();
        } else {
            $stmt->close();
            $conn->close();
            header("Location: suprime.php?error=mdp_incorrect");
            exit();
        }
    } else {
        $stmt->close();
        $conn->close();
        header("Location: suprime.php?error=introuvable");
        exit();
    }
} else {
    header("Location: suprime.php");
    exit();
}
