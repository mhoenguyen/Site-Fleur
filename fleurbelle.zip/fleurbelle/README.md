# FleurBelle 🌸 — Guide d'installation

## Prérequis
- XAMPP / WAMP / MAMP avec PHP 7.4+
- phpMyAdmin
- Navigateur web

---

## Installation en 4 étapes

### 1. Copier les fichiers
Copiez tout le dossier `fleurbelle/` dans :
- **XAMPP** : `C:/xampp/htdocs/fleurbelle/`
- **WAMP**  : `C:/wamp64/www/fleurbelle/`
- **MAMP**  : `/Applications/MAMP/htdocs/fleurbelle/`

### 2. Importer la base de données
1. Ouvrez **phpMyAdmin** → `http://localhost/phpmyadmin`
2. Cliquez sur **Importer** (onglet du haut)
3. Sélectionnez le fichier `fleurbelle.sql`
4. Cliquez sur **Exécuter**

La base `fleur` sera créée automatiquement avec toutes les tables et données de démonstration.

### 3. Configurer la connexion
Ouvrez `config.php` et modifiez :
```php
define('DB_USER', 'root');          // votre nom d'utilisateur MySQL
define('DB_PASS', '');              // votre mot de passe MySQL (vide sur XAMPP par défaut)
```

### 4. Lancer le site
Ouvrez : `http://localhost/fleurbelle/acceuil.php`

---

## Compte de test
| Champ | Valeur |
|-------|--------|
| Utilisateur | `admin` |
| Mot de passe | `password` |

---

## Structure des fichiers
```
fleurbelle/
├── config.php                  ← Connexion DB (modifier ici)
├── acceuil.php                 ← Page principale
├── user.php                    ← Connexion / Mon compte
├── login.php                   ← Traitement connexion
├── logout.php                  ← Déconnexion
├── inscreption.php             ← Formulaire inscription
├── traitement_inscription.php  ← Traitement inscription
├── modifier_compte.php         ← Formulaire modification
├── modification.php            ← Traitement modification
├── suprime.php                 ← Formulaire suppression compte
├── supprimer_utilisateur.php   ← Traitement suppression
├── panier.php                  ← Ajout au panier
├── affichage_panier.php        ← Page panier
├── commande.php                ← Validation commande
├── resume.php                  ← Historique commandes
├── recherche_produit.php       ← Recherche produits
├── ajouter_commentaire.php     ← Ajout avis
├── contact.php                 ← Formulaire contact
├── style.css                   ← Styles CSS
├── fleurbelle.sql              ← Base de données
└── images/                     ← Vos images (img-1.jpg ... img-7.jpg)
```

## Images requises
Placez vos images dans le dossier `images/` :
- img-1.jpg, img-2.jpg, img-3.jpg, img-4.jpg
- img-5.jpg, img-6.png, img-7.jpg
- background.png (optionnel)

---

## Améliorations apportées
✅ Protection SQL Injection (Prepared Statements)  
✅ Mots de passe hashés avec `password_hash()`  
✅ Sessions sécurisées  
✅ Tous les liens corrigés  
✅ Bug panier corrigé (variable `$id_produit`)  
✅ Colonne `prix` dans commande corrigée  
✅ CSS enrichi (commentaires, footer, flash messages)  
✅ Pages `.html` converties en `.php` pour les sessions  
✅ Fichier `config.php` centralisé  
✅ Page 404 / redirections correctes  
