<?php
require_once 'config.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: user.php");
    exit();
}
$id_utilisateur = $_SESSION['id_utilisateur'];

$conn = getConnexion();
$stmt = $conn->prepare("SELECT id_produit, prix, Quantite FROM panier WHERE id_utilisateur = ?");
$stmt->bind_param("i", $id_utilisateur);
$stmt->execute();
$resultat = $stmt->get_result();
$items = [];
$total = 0;
while ($row = $resultat->fetch_assoc()) {
    $items[] = $row;
    $total += $row['prix'];
}
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FleurBelle – Mon panier</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: rgb(255, 234, 247); padding-top: 100px; }
        .panier-container { max-width: 800px; margin: 40px auto; padding: 0 20px; }
        .panier-card { background: #fff; border-radius: 12px; padding: 30px 35px; box-shadow: 0 5px 20px rgba(0,0,0,.1); }
        .panier-card h2 { font-size: 2.5rem; color: #333; margin-bottom: 25px; }
        table { width: 100%; border-collapse: collapse; }
        thead th { background: var(--pink); color: #fff; padding: 12px 15px; font-size: 1.5rem; text-align: left; }
        tbody td { padding: 12px 15px; font-size: 1.5rem; border-bottom: 1px solid #f0f0f0; }
        tbody tr:hover { background: rgba(232,67,147,.04); }
        .total-row { font-size: 1.8rem; font-weight: bold; color: var(--pink); padding: 15px; text-align: right; }
        .actions { display: flex; gap: 15px; justify-content: flex-end; margin-top: 20px; flex-wrap: wrap; }
        .btn-outline { background: transparent; color: #333; border: 2px solid #333; padding: .8rem 3rem; border-radius: 5rem; font-size: 1.5rem; cursor: pointer; }
        .btn-outline:hover { background: #333; color: #fff; }
        .empty-msg { text-align: center; padding: 40px; font-size: 1.7rem; color: #999; }
        .empty-msg i { font-size: 4rem; color: #ddd; display: block; margin-bottom: 15px; }
    </style>
</head>
<body>
<header>
    <a href="acceuil.php" class="logo">FleurBelle <span>.</span></a>
    <div class="icons">
        <a href="acceuil.php"><i class="fas fa-home"></i> Home</a>
        <a href="affichage_panier.php"><i class="fas fa-shopping-cart"></i> Panier</a>
        <a href="acceuil.php#products"><i class="fas fa-leaf"></i> Produits</a>
        <a href="user.php"><i class="fas fa-user"></i> Mon compte</a>
    </div>
</header>

<div class="panier-container">
    <div class="panier-card">
        <h2><i class="fas fa-shopping-cart" style="color:var(--pink)"></i> Mon panier</h2>

        <?php if (count($items) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th><i class="fas fa-box"></i> Produit</th>
                    <th><i class="fas fa-sort-numeric-up"></i> Quantité</th>
                    <th><i class="fas fa-tag"></i> Prix total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item["id_produit"]) ?></td>
                    <td><?= intval($item["Quantite"]) ?></td>
                    <td>$<?= number_format($item["prix"], 2) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="total-row">
            Total : $<?= number_format($total, 2) ?>
        </div>

        <div class="actions">
            <a href="acceuil.php#products" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Continuer mes achats
            </a>
            <form action="commande.php" method="post">
                <button type="submit" class="btn">
                    <i class="fas fa-check-circle"></i> Passer la commande
                </button>
            </form>
        </div>
        <?php else: ?>
        <div class="empty-msg">
            <i class="fas fa-shopping-basket"></i>
            Votre panier est vide.<br>
            <a href="acceuil.php#products" class="btn" style="margin-top:20px;">
                Voir nos produits
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
