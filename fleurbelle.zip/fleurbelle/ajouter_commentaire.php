<?php
require_once 'config.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: user.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_utilisateur = $_SESSION['id_utilisateur'];
    $id_produit     = trim($_POST['id_produit'] ?? '');
    $commentaire    = trim($_POST['commentaire'] ?? '');
    $note           = intval($_POST['rating'] ?? 0);

    if (empty($id_produit) || empty($commentaire) || $note < 1 || $note > 5) {
        header("Location: acceuil.php?error=commentaire_invalide");
        exit();
    }

    $conn = getConnexion();
    $stmt = $conn->prepare("INSERT INTO commentaire (id_utilisateur, nom_produit, Commentaire, note) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("issi", $id_utilisateur, $id_produit, $commentaire, $note);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        header("Location: acceuil.php?success=commentaire_ajoute#comments");
        exit();
    } else {
        $stmt->close();
        $conn->close();
        header("Location: acceuil.php?error=erreur_commentaire");
        exit();
    }
} else {
    header("Location: acceuil.php");
    exit();
}
