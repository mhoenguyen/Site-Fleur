<?php
// =============================================
// config.php — Connexion à la base de données
// Modifiez ces valeurs selon votre configuration
// =============================================

define('DB_HOST', '127.0.0.1:8889');
define('DB_USER', 'root');   // ← changez ici
define('DB_PASS', 'root'); // ← changez ici
define('DB_NAME', 'fleur');

function getConnexion(): mysqli {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die("Erreur de connexion : " . $conn->connect_error);
    }
    $conn->set_charset('utf8mb4');
    return $conn;
}

// Démarrer la session si pas encore démarrée
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
