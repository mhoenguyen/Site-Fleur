<?php
require_once 'config.php';
$estConnecte = isset($_SESSION['id_utilisateur']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FleurBelle – Mon compte</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: rgb(255, 234, 247); padding-top: 100px; }
        .auth-container {
            max-width: 450px;
            margin: 40px auto;
            padding: 0 20px;
        }
        .auth-card {
            background: #fff;
            border-radius: 12px;
            padding: 35px 40px;
            box-shadow: 0 5px 20px rgba(0,0,0,.1);
        }
        .auth-card h2 {
            font-size: 2.2rem;
            color: #333;
            margin-bottom: 25px;
            text-align: center;
        }
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; font-size: 1.4rem; color: #555; margin-bottom: 6px; }
        .form-group input {
            width: 100%;
            padding: 11px 14px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1.5rem;
            box-sizing: border-box;
            transition: border-color .2s;
        }
        .form-group input:focus { border-color: var(--pink); }
        .btn-full { width: 100%; text-align: center; margin-top: 8px; font-size: 1.6rem; }
        .divider { text-align: center; margin: 20px 0; color: #aaa; font-size: 1.4rem; }
        .link-row { text-align: center; font-size: 1.4rem; margin-top: 15px; color: #555; }
        .link-row a { color: var(--pink); }
        .alert { padding: 12px; border-radius: 6px; font-size: 1.4rem; margin-bottom: 15px; text-align: center; }
        .alert-success { background: #d4edda; color: #155724; }
        .alert-error { background: #f8d7da; color: #721c24; }
        .account-menu a {
            display: flex; align-items: center; gap: 10px;
            padding: 12px 15px; border-radius: 8px; color: #333;
            font-size: 1.5rem; text-decoration: none; margin-bottom: 8px;
            background: #f9f9f9; transition: background .2s;
        }
        .account-menu a:hover { background: rgba(232,67,147,.1); color: var(--pink); }
        .account-menu a i { width: 20px; text-align: center; }
        .btn-danger { background: #e74c3c; }
        .btn-danger:hover { background: #c0392b; }
    </style>
</head>
<body>
<header>
    <a href="acceuil.php" class="logo">FleurBelle <span>.</span></a>
    <div class="icons">
        <a href="acceuil.php"><i class="fas fa-home"></i> Home</a>
        <a href="affichage_panier.php"><i class="fas fa-shopping-cart"></i> Panier</a>
        <a href="acceuil.php#products"><i class="fas fa-leaf"></i> Produits</a>
        <a href="user.php"><i class="fas fa-user"></i> Connexion</a>
    </div>
</header>

<div class="auth-container">
<?php if ($estConnecte): ?>
    <!-- Utilisateur connecté -->
    <div class="auth-card">
        <h2><i class="fas fa-user-circle" style="color:var(--pink)"></i> Mon compte</h2>
        <p style="text-align:center;font-size:1.5rem;color:#666;margin-bottom:20px;">
            Bonjour, <strong><?= htmlspecialchars($_SESSION['nom_utilisateur'] ?? '') ?></strong> !
        </p>
        <div class="account-menu">
            <a href="resume.php"><i class="fas fa-box"></i> Mes commandes</a>
            <a href="affichage_panier.php"><i class="fas fa-shopping-cart"></i> Mon panier</a>
            <a href="modifier_compte.php"><i class="fas fa-edit"></i> Modifier mon compte</a>
            <a href="suprime.php"><i class="fas fa-trash"></i> Supprimer mon compte</a>
        </div>
        <form action="logout.php" method="post" style="margin-top:20px;">
            <button type="submit" class="btn btn-full btn-danger">
                <i class="fas fa-sign-out-alt"></i> Se déconnecter
            </button>
        </form>
    </div>
<?php else: ?>
    <!-- Formulaire de connexion -->
    <?php
    $msg = '';
    $type = '';
    if (isset($_GET['msg'])) {
        $msgs = [
            'deconnecte'  => ['Vous avez été déconnecté.', 'success'],
            'inscription' => ['Inscription réussie ! Vous pouvez vous connecter.', 'success'],
            'supprime'    => ['Votre compte a été supprimé.', 'success'],
            'modifie'     => ['Compte modifié avec succès.', 'success'],
        ];
        if (isset($msgs[$_GET['msg']])) {
            [$msg, $type] = $msgs[$_GET['msg']];
        }
    }
    ?>
    <?php if ($msg): ?>
        <div class="alert alert-<?= $type ?>"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <div class="auth-card">
        <h2><i class="fas fa-sign-in-alt" style="color:var(--pink)"></i> Connexion</h2>
        <form action="login.php" method="post">
            <div class="form-group">
                <label for="username"><i class="fas fa-user"></i> Nom d'utilisateur</label>
                <input type="text" id="username" name="username" placeholder="Votre nom d'utilisateur" required>
            </div>
            <div class="form-group">
                <label for="password"><i class="fas fa-lock"></i> Mot de passe</label>
                <input type="password" id="password" name="password" placeholder="Votre mot de passe" required>
            </div>
            <button type="submit" class="btn btn-full">Se connecter</button>
        </form>
        <div class="divider">— ou —</div>
        <div class="link-row">
            Pas encore de compte ? <a href="inscreption.php">S'inscrire</a>
        </div>
    </div>
<?php endif; ?>
</div>
</body>
</html>
