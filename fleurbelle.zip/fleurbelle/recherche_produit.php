<?php
require_once 'config.php';
$estConnecte = isset($_SESSION['id_utilisateur']);
$motcle = trim($_GET['motcle'] ?? '');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FleurBelle – Recherche</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: rgb(255, 234, 247); padding-top: 100px; }
        .search-container { max-width: 900px; margin: 40px auto; padding: 0 20px; }
        .search-header { font-size: 2rem; color: #333; margin-bottom: 25px; }
        .search-header span { color: var(--pink); }
        .search-bar { display: flex; gap: 10px; margin-bottom: 30px; }
        .search-bar input { flex: 1; padding: 12px 18px; border: 2px solid #ddd; border-radius: 30px; font-size: 1.6rem; }
        .search-bar input:focus { border-color: var(--pink); outline: none; }
        .results-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; }
        .result-card { background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 3px 15px rgba(0,0,0,.08); }
        .result-card h3 { font-size: 1.8rem; color: #333; margin-bottom: 8px; }
        .result-card .price { font-size: 2rem; color: var(--pink); font-weight: bold; margin-bottom: 12px; }
        .result-card .stock { font-size: 1.3rem; color: #888; margin-bottom: 12px; }
        .comment-block { background: #f9f9f9; border-radius: 8px; padding: 10px 12px; margin-top: 12px; font-size: 1.3rem; color: #555; }
        .stars-sm i { color: var(--pink); font-size: 1.2rem; }
        .no-result { text-align: center; padding: 60px 20px; font-size: 1.7rem; color: #999; }
    </style>
</head>
<body>
<header>
    <a href="acceuil.php" class="logo">FleurBelle <span>.</span></a>
    <div class="icons">
        <a href="acceuil.php"><i class="fas fa-home"></i> Home</a>
        <a href="affichage_panier.php"><i class="fas fa-shopping-cart"></i> Panier</a>
        <a href="user.php"><i class="fas fa-user"></i> <?= $estConnecte ? htmlspecialchars($_SESSION['nom_utilisateur']) : 'Connexion' ?></a>
    </div>
</header>

<div class="search-container">
    <!-- Barre de recherche -->
    <form action="recherche_produit.php" method="GET" class="search-bar">
        <input type="text" name="motcle" value="<?= htmlspecialchars($motcle) ?>" placeholder="Rechercher un produit...">
        <button type="submit" class="btn"><i class="fas fa-search"></i> Rechercher</button>
    </form>

    <?php if (!empty($motcle)): ?>
    <p class="search-header">
        Résultats pour : <span>"<?= htmlspecialchars($motcle) ?>"</span>
    </p>

    <?php
    $conn = getConnexion();
    $motcleSearch = '%' . $motcle . '%';
    $stmt = $conn->prepare("SELECT * FROM produit WHERE NomProduit LIKE ?");
    $stmt->bind_param("s", $motcleSearch);
    $stmt->execute();
    $resultat = $stmt->get_result();
    $stmt->close();

    if ($resultat->num_rows > 0):
    ?>
    <div class="results-grid">
    <?php while ($row = $resultat->fetch_assoc()): ?>
        <div class="result-card">
            <h3><?= htmlspecialchars($row['NomProduit']) ?></h3>
            <div class="price">$<?= number_format($row['PrixProduit'], 2) ?></div>
            <div class="stock">
                <?php if ($row['stock'] > 0): ?>
                    <i class="fas fa-check-circle" style="color:green"></i> En stock (<?= $row['stock'] ?> restants)
                <?php else: ?>
                    <i class="fas fa-times-circle" style="color:red"></i> Rupture de stock
                <?php endif; ?>
            </div>

            <?php if ($row['stock'] > 0): ?>
            <form action="panier.php" method="post">
                <input type="hidden" name="nom_produit" value="<?= htmlspecialchars($row['NomProduit']) ?>">
                <input type="hidden" name="prix_produit" value="<?= $row['PrixProduit'] ?>">
                <button type="submit" name="ajouter_panier" class="btn" style="width:100%">
                    <i class="fas fa-cart-plus"></i> Ajouter au panier
                </button>
            </form>
            <?php endif; ?>

            <?php
            // Commentaires du produit
            $nomProd = $row['NomProduit'];
            $stmtCom = $conn->prepare("SELECT c.Commentaire, c.note, u.nom FROM commentaire c LEFT JOIN utilisateur u ON c.id_utilisateur = u.id_utilisateur WHERE c.nom_produit = ? ORDER BY c.date_commentaire DESC LIMIT 3");
            $stmtCom->bind_param("s", $nomProd);
            $stmtCom->execute();
            $resCom = $stmtCom->get_result();
            if ($resCom->num_rows > 0):
            ?>
            <div style="margin-top:12px;">
                <strong style="font-size:1.3rem;color:#333;">Avis clients :</strong>
                <?php while ($com = $resCom->fetch_assoc()): ?>
                <div class="comment-block">
                    <div class="stars-sm">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <i class="fas fa-star" style="color:<?= $i <= $com['note'] ? 'var(--pink)' : '#ddd' ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <p>"<?= htmlspecialchars($com['Commentaire']) ?>"</p>
                    <small>— <?= htmlspecialchars($com['nom'] ?? 'Anonyme') ?></small>
                </div>
                <?php endwhile; ?>
            </div>
            <?php endif; $stmtCom->close(); ?>
        </div>
    <?php endwhile; ?>
    </div>

    <?php else: ?>
    <div class="no-result">
        <i class="fas fa-search" style="font-size:4rem;color:#ddd;display:block;margin-bottom:15px;"></i>
        Aucun produit trouvé pour "<?= htmlspecialchars($motcle) ?>".<br>
        <a href="acceuil.php#products" class="btn" style="margin-top:20px;">Voir tous les produits</a>
    </div>
    <?php endif;
    $conn->close();
    ?>

    <?php else: ?>
    <div class="no-result">
        <i class="fas fa-search" style="font-size:4rem;color:#ddd;display:block;margin-bottom:15px;"></i>
        Entrez un mot-clé pour rechercher un produit.
    </div>
    <?php endif; ?>
</div>
</body>
</html>
