<?php
require_once 'config.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: user.php");
    exit();
}
$id_utilisateur = $_SESSION['id_utilisateur'];

$conn = getConnexion();
$stmt = $conn->prepare("SELECT id_commande, produit, Quantite, prix, date_commande FROM commande WHERE id_utilisateur = ? ORDER BY date_commande DESC");
$stmt->bind_param("i", $id_utilisateur);
$stmt->execute();
$resultat = $stmt->get_result();
$commandes = [];
$totalGeneral = 0;
while ($row = $resultat->fetch_assoc()) {
    $commandes[] = $row;
    $totalGeneral += $row['prix'];
}
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FleurBelle – Mes commandes</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: rgb(255, 234, 247); padding-top: 100px; }
        .resume-container { max-width: 900px; margin: 40px auto; padding: 0 20px; }
        .resume-card { background: #fff; border-radius: 12px; padding: 30px 35px; box-shadow: 0 5px 20px rgba(0,0,0,.1); }
        .resume-card h2 { font-size: 2.5rem; color: #333; margin-bottom: 25px; }
        table { width: 100%; border-collapse: collapse; }
        thead th { background: var(--pink); color: #fff; padding: 12px 15px; font-size: 1.5rem; text-align: left; }
        tbody td { padding: 12px 15px; font-size: 1.4rem; border-bottom: 1px solid #f0f0f0; }
        tbody tr:hover { background: rgba(232,67,147,.04); }
        .total-row { font-size: 1.8rem; font-weight: bold; color: var(--pink); padding: 15px; text-align: right; }
        .badge { background: rgba(232,67,147,.15); color: var(--pink); padding: 4px 10px; border-radius: 20px; font-size: 1.2rem; }
        .empty-msg { text-align: center; padding: 40px; font-size: 1.7rem; color: #999; }
        .back-btn { margin-top: 20px; }
    </style>
</head>
<body>
<header>
    <a href="acceuil.php" class="logo">FleurBelle <span>.</span></a>
    <div class="icons">
        <a href="acceuil.php"><i class="fas fa-home"></i> Home</a>
        <a href="affichage_panier.php"><i class="fas fa-shopping-cart"></i> Panier</a>
        <a href="user.php"><i class="fas fa-user"></i> Mon compte</a>
    </div>
</header>

<div class="resume-container">
    <div class="resume-card">
        <h2><i class="fas fa-box-open" style="color:var(--pink)"></i> Mes commandes</h2>

        <?php if (count($commandes) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th># Commande</th>
                    <th>Produit</th>
                    <th>Quantité</th>
                    <th>Prix</th>
                    <th>Date</th>
                    <th>Statut</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($commandes as $cmd): ?>
                <tr>
                    <td><strong>#<?= $cmd['id_commande'] ?></strong></td>
                    <td><?= htmlspecialchars($cmd['produit']) ?></td>
                    <td><?= intval($cmd['Quantite']) ?></td>
                    <td>$<?= number_format($cmd['prix'], 2) ?></td>
                    <td><?= date('d/m/Y H:i', strtotime($cmd['date_commande'])) ?></td>
                    <td><span class="badge"><i class="fas fa-check"></i> Confirmée</span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="total-row">
            Total dépensé : $<?= number_format($totalGeneral, 2) ?>
        </div>
        <?php else: ?>
        <div class="empty-msg">
            <i class="fas fa-box" style="font-size:4rem;color:#ddd;display:block;margin-bottom:15px;"></i>
            Vous n'avez encore passé aucune commande.
        </div>
        <?php endif; ?>

        <div class="back-btn">
            <a href="acceuil.php#products" class="btn"><i class="fas fa-leaf"></i> Voir les produits</a>
            <a href="user.php" class="btn" style="margin-left:10px;background:#555;">
                <i class="fas fa-user"></i> Mon compte
            </a>
        </div>
    </div>
</div>
</body>
</html>
