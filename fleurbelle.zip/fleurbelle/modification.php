<?php
require_once 'config.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: user.php"); exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username    = trim($_POST['username'] ?? '');
    $password    = trim($_POST['password'] ?? '');
    $newUsername = trim($_POST['username2'] ?? '');
    $newPassword = trim($_POST['password2'] ?? '');
    $newAddress  = trim($_POST['adresse2'] ?? '');

    $conn = getConnexion();

    // Vérifier l'identité actuelle
    $stmt = $conn->prepare("SELECT id_utilisateur, mdp FROM utilisateur WHERE nom = ? AND id_utilisateur = ?");
    $id = $_SESSION['id_utilisateur'];
    $stmt->bind_param("si", $username, $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $passwordOk = password_verify($password, $row['mdp']) || ($password === $row['mdp']);

        if ($passwordOk) {
            $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmtUp = $conn->prepare("UPDATE utilisateur SET nom = ?, mdp = ?, adresse = ? WHERE id_utilisateur = ?");
            $stmtUp->bind_param("sssi", $newUsername, $newHash, $newAddress, $id);
            if ($stmtUp->execute()) {
                $_SESSION['nom_utilisateur'] = $newUsername;
                $stmtUp->close();
                $stmt->close();
                $conn->close();
                header("Location: user.php?msg=modifie");
                exit();
            } else {
                $stmtUp->close();
            }
        } else {
            $stmt->close();
            $conn->close();
            header("Location: modifier_compte.php?error=mdp_incorrect");
            exit();
        }
    } else {
        $stmt->close();
        $conn->close();
        header("Location: modifier_compte.php?error=utilisateur_introuvable");
        exit();
    }
    $conn->close();
} else {
    header("Location: modifier_compte.php");
    exit();
}
