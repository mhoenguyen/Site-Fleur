<?php
require_once 'config.php';
$estConnecte = isset($_SESSION['id_utilisateur']);
$nomUtilisateur = $estConnecte ? htmlspecialchars($_SESSION['nom_utilisateur'] ?? '') : '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FleurBelle – Fleurs & Bouquets</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <a href="acceuil.php" class="logo">FleurBelle <span>.</span></a>
    <div class="icons">
        <a href="acceuil.php"><i class="fas fa-home"></i> Home</a>
        <a href="affichage_panier.php"><i class="fas fa-shopping-cart"></i> Panier</a>
        <a href="#products"><i class="fas fa-leaf"></i> Produits</a>
        <?php if ($estConnecte): ?>
            <a href="user.php"><i class="fas fa-user"></i> <?= $nomUtilisateur ?></a>
        <?php else: ?>
            <a href="user.php"><i class="fas fa-user"></i> Connexion</a>
        <?php endif; ?>
        <form action="recherche_produit.php" method="GET" style="display:inline-flex;gap:5px;margin-left:10px;">
            <input type="text" placeholder="Rechercher..." name="motcle" class="search-input">
            <button type="submit" class="btn btn-sm"><i class="fas fa-search"></i></button>
        </form>
    </div>
</header>

<!-- HOME -->
<section class="home" id="home">
    <div class="content">
        <h3>FleurBelle</h3>
        <span>Des fleurs pour chaque moment</span>
        <p>Le langage des fleurs, vieux de siècles, témoigne de leur pouvoir évocateur.</p>
        <a href="#products" class="btn">Shop Now <i class="fas fa-arrow-right"></i></a>
    </div>
</section>

<!-- ABOUT -->
<section class="about" id="about">
    <h1 class="heading"><span>À propos</span> de nous</h1>
    <div class="row">
        <div class="video-container">
            <video autoplay loop muted playsinline>
                <source src="images/blossoms_-_113004 (540p).mp4" type="video/mp4">
            </video>
            <h3>Les meilleurs fleuristes</h3>
        </div>
        <div class="content">
            <h3>Notre passion, les fleurs</h3>
            <p>Chez FleurBelle, nous sélectionnons les plus belles fleurs pour vous offrir des bouquets uniques, livrés frais directement chez vous.</p>
            <p>Chaque bouquet est préparé avec soin par nos fleuristes experts pour rendre chaque occasion inoubliable.</p>
            <a href="#contact" class="btn">Nous contacter</a>
        </div>
    </div>
</section>

<!-- AVANTAGES -->
<section class="icons-container">
    <div class="icons">
        <i class="fas fa-truck fa-2x" style="color:var(--pink);margin-right:15px;"></i>
        <div class="info">
            <h3>Livraison gratuite</h3>
            <span>Sur toutes les commandes</span>
        </div>
    </div>
    <div class="icons">
        <i class="fas fa-undo fa-2x" style="color:var(--pink);margin-right:15px;"></i>
        <div class="info">
            <h3>Retour en 10 jours</h3>
            <span>Satisfait ou remboursé</span>
        </div>
    </div>
    <div class="icons">
        <i class="fas fa-gift fa-2x" style="color:var(--pink);margin-right:15px;"></i>
        <div class="info">
            <h3>Emballage cadeau</h3>
            <span>Sur toutes les commandes</span>
        </div>
    </div>
    <div class="icons">
        <i class="fas fa-lock fa-2x" style="color:var(--pink);margin-right:15px;"></i>
        <div class="info">
            <h3>Paiement sécurisé</h3>
            <span>Protégé par PayPal</span>
        </div>
    </div>
</section>

<!-- PRODUCTS -->
<section class="products" id="products">
    <h1 class="heading">Nos <span>produits</span></h1>

    <?php
    $conn = getConnexion();
    // Tự động nhận diện đuôi file (jpg, jpeg, png, webp)
    function findImage(string $base): string {
        $exts = ['jpg', 'jpeg', 'png', 'webp'];
        foreach ($exts as $ext) {
            if (file_exists(__DIR__ . "/images/{$base}.{$ext}")) {
                return "images/{$base}.{$ext}";
            }
        }
        return "images/{$base}.jpg"; // fallback
    }

    $produits = [
        ['nom' => 'Flower pot 1', 'prix_affiche' => 17.99, 'prix_reel' => 15.99, 'discount' => -10, 'img' => findImage('pot1')],
        ['nom' => 'Flower pot 2', 'prix_affiche' => 13.99, 'prix_reel' => 15.99, 'discount' => -15, 'img' => findImage('pot2')],
        ['nom' => 'Flower pot 3', 'prix_affiche' => 14.99, 'prix_reel' => 15.99, 'discount' => -5,  'img' => findImage('pot3')],
        ['nom' => 'Flower pot 4', 'prix_affiche' => 12.99, 'prix_reel' => 15.99, 'discount' => -20, 'img' => findImage('pot4')],
        ['nom' => 'Flower pot 5', 'prix_affiche' => 14.99, 'prix_reel' => 15.99, 'discount' => -17, 'img' => findImage('pot5')],
        ['nom' => 'Flower pot 6', 'prix_affiche' => 18.99, 'prix_reel' => 15.99, 'discount' => -3,  'img' => findImage('pot6')],
        ['nom' => 'Flower pot 7', 'prix_affiche' => 15.99, 'prix_reel' => 15.99, 'discount' => -18, 'img' => findImage('pot7')],
    ];
    ?>

    <div class="box-container">
    <?php foreach ($produits as $p): ?>
        <div class="box">
            <span class="discount"><?= $p['discount'] ?>%</span>
            <div class="image">
                <img src="<?= htmlspecialchars($p['img']) ?>" alt="<?= htmlspecialchars($p['nom']) ?>">
                <div class="icons">
                    <form action="panier.php" method="post">
                        <input type="hidden" name="nom_produit" value="<?= htmlspecialchars($p['nom']) ?>">
                        <input type="hidden" name="prix_produit" value="<?= $p['prix_reel'] ?>">
                        <button type="submit" name="ajouter_panier" class="cart-btn">
                            <i class="fas fa-cart-plus"></i> Ajouter au panier
                        </button>
                    </form>
                </div>
            </div>
            <div class="content">
                <h3><?= htmlspecialchars($p['nom']) ?></h3>
                <div class="price">
                    $<?= number_format($p['prix_affiche'], 2) ?>
                    <span>$<?= number_format($p['prix_reel'], 2) ?></span>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
    <?php $conn->close(); ?>
</section>

<!-- COMMENTAIRES & NOTES -->
<section class="comments" id="comments">
    <h1 class="heading">Avis <span>clients</span></h1>

    <?php
    // Afficher les commentaires existants
    $conn2 = getConnexion();
    $sqlCom = "SELECT c.nom_produit, c.Commentaire, c.note, u.nom AS auteur, c.date_commentaire
               FROM commentaire c
               LEFT JOIN utilisateur u ON c.id_utilisateur = u.id_utilisateur
               WHERE c.nom_produit IS NOT NULL
               ORDER BY c.date_commentaire DESC LIMIT 6";
    $resCom = $conn2->query($sqlCom);
    if ($resCom && $resCom->num_rows > 0):
    ?>
    <div class="review box-container" style="margin-bottom:2rem;">
    <?php while ($com = $resCom->fetch_assoc()): ?>
        <div class="box">
            <div class="stars">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                    <i class="fas fa-star<?= $i > $com['note'] ? '-empty' : '' ?>"
                       style="color:<?= $i <= $com['note'] ? 'var(--pink)' : '#ccc' ?>"></i>
                <?php endfor; ?>
            </div>
            <p>"<?= htmlspecialchars($com['Commentaire']) ?>"</p>
            <div class="user">
                <div>
                    <h3><?= htmlspecialchars($com['auteur'] ?? 'Anonyme') ?></h3>
                    <span style="font-size:1.3rem;color:#aaa;">
                        <?= htmlspecialchars($com['nom_produit']) ?> •
                        <?= date('d/m/Y', strtotime($com['date_commentaire'])) ?>
                    </span>
                </div>
            </div>
            <i class="fas fa-quote-right"></i>
        </div>
    <?php endwhile; ?>
    </div>
    <?php endif; $conn2->close(); ?>

    <!-- Formulaire ajouter commentaire -->
    <?php if ($estConnecte): ?>
    <div class="comment-form-container">
        <h2 style="text-align:center;font-size:2rem;margin-bottom:1.5rem;color:#333;">Laisser un avis</h2>
        <form action="ajouter_commentaire.php" method="post" class="comment-form">
            <div class="form-group">
                <label for="id_produit">Produit :</label>
                <select name="id_produit" id="id_produit" required>
                    <option value="">-- Choisir un produit --</option>
                    <?php foreach ($produits as $p): ?>
                        <option value="<?= htmlspecialchars($p['nom']) ?>"><?= htmlspecialchars($p['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="commentaire">Votre avis :</label>
                <textarea name="commentaire" id="commentaire" placeholder="Partagez votre expérience..." required></textarea>
            </div>
            <div class="form-group">
                <label>Note :</label>
                <div class="star-rating">
                    <?php for ($i = 5; $i >= 1; $i--): ?>
                        <input type="radio" name="rating" id="star<?= $i ?>" value="<?= $i ?>" required>
                        <label for="star<?= $i ?>"><i class="fas fa-star"></i></label>
                    <?php endfor; ?>
                </div>
            </div>
            <button type="submit" class="btn">Envoyer l'avis <i class="fas fa-paper-plane"></i></button>
        </form>
    </div>
    <?php else: ?>
    <p style="text-align:center;font-size:1.6rem;color:#666;">
        <a href="user.php" style="color:var(--pink);">Connectez-vous</a> pour laisser un avis.
    </p>
    <?php endif; ?>
</section>

<!-- CONTACT -->
<section class="contact" id="contact">
    <h1 class="heading"><span>Contactez</span>-nous</h1>
    <div class="row">
        <form action="contact.php" method="POST" id="contactForm">
            <input type="text" name="nom" placeholder="Votre nom *" class="box" required>
            <input type="email" name="mail" placeholder="Votre email *" class="box" required>
            <input type="tel" name="phone" placeholder="Téléphone (ex: 06 10 30 49 00)" class="box">
            <textarea name="mess" placeholder="Votre message *" class="box" required></textarea>
            <button type="submit" class="btn">Envoyer <i class="fas fa-paper-plane"></i></button>
        </form>
        <div class="image">
            <div class="contact-info">
                <h3><i class="fas fa-map-marker-alt" style="color:var(--pink)"></i> Adresse</h3>
                <p>12 rue des Fleurs, 75001 Paris</p>
                <h3><i class="fas fa-phone" style="color:var(--pink)"></i> Téléphone</h3>
                <p>+33 1 23 45 67 89</p>
                <h3><i class="fas fa-envelope" style="color:var(--pink)"></i> Email</h3>
                <p>contact@fleurbelle.fr</p>
            </div>
        </div>
    </div>
</section>

<!-- FOOTER -->
<footer class="footer">
    <div class="box-container">
        <div class="box">
            <h3>FleurBelle</h3>
            <p style="font-size:1.4rem;color:#666;line-height:1.6">Votre boutique de fleurs en ligne. Des bouquets frais livrés avec amour.</p>
        </div>
        <div class="box">
            <h3>Liens rapides</h3>
            <a href="acceuil.php">Accueil</a>
            <a href="#about">À propos</a>
            <a href="#products">Produits</a>
            <a href="#contact">Contact</a>
        </div>
        <div class="box">
            <h3>Mon compte</h3>
            <a href="user.php">Connexion</a>
            <a href="inscreption.php">Inscription</a>
            <a href="affichage_panier.php">Mon panier</a>
            <a href="resume.php">Mes commandes</a>
        </div>
        <div class="box">
            <h3>Suivez-nous</h3>
            <a href="#"><i class="fab fa-facebook"></i> Facebook</a>
            <a href="#"><i class="fab fa-instagram"></i> Instagram</a>
            <a href="#"><i class="fab fa-twitter"></i> Twitter</a>
        </div>
    </div>
    <div class="credit">
        &copy; 2024 <span>FleurBelle</span> — Tous droits réservés
    </div>
</footer>

</body>
</html>
