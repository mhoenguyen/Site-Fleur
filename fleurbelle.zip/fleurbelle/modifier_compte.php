<?php require_once 'config.php';
if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: user.php"); exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FleurBelle – Modifier mon compte</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: rgb(255, 234, 247); padding-top: 100px; }
        .auth-container { max-width: 480px; margin: 40px auto; padding: 0 20px; }
        .auth-card { background: #fff; border-radius: 12px; padding: 35px 40px; box-shadow: 0 5px 20px rgba(0,0,0,.1); }
        .auth-card h2 { font-size: 2.2rem; color: #333; margin-bottom: 10px; text-align: center; }
        .section-label { font-size: 1.3rem; color: #aaa; text-transform: uppercase; letter-spacing: 1px; margin: 18px 0 10px; border-bottom: 1px solid #eee; padding-bottom: 5px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 1.4rem; color: #555; margin-bottom: 5px; }
        .form-group input { width: 100%; padding: 11px 14px; border: 1px solid #ddd; border-radius: 8px; font-size: 1.5rem; box-sizing: border-box; }
        .form-group input:focus { border-color: var(--pink); outline: none; }
        .btn-full { width: 100%; text-align: center; font-size: 1.6rem; margin-top: 10px; }
        .back-link { text-align: center; margin-top: 15px; font-size: 1.4rem; }
        .back-link a { color: var(--pink); }
    </style>
</head>
<body>
<header>
    <a href="acceuil.php" class="logo">FleurBelle <span>.</span></a>
    <div class="icons">
        <a href="acceuil.php"><i class="fas fa-home"></i> Home</a>
        <a href="affichage_panier.php"><i class="fas fa-shopping-cart"></i> Panier</a>
        <a href="user.php"><i class="fas fa-user"></i> Mon compte</a>
    </div>
</header>

<div class="auth-container">
    <div class="auth-card">
        <h2><i class="fas fa-edit" style="color:var(--pink)"></i> Modifier mon compte</h2>

        <form action="modification.php" method="post">
            <p class="section-label">Identification actuelle</p>
            <div class="form-group">
                <label><i class="fas fa-user"></i> Nom d'utilisateur actuel</label>
                <input type="text" name="username" value="<?= htmlspecialchars($_SESSION['nom_utilisateur'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Mot de passe actuel</label>
                <input type="password" name="password" placeholder="Votre mot de passe actuel" required>
            </div>

            <p class="section-label">Nouvelles informations</p>
            <div class="form-group">
                <label><i class="fas fa-user-edit"></i> Nouveau nom d'utilisateur</label>
                <input type="text" name="username2" placeholder="Nouveau nom d'utilisateur" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-key"></i> Nouveau mot de passe</label>
                <input type="password" name="password2" placeholder="Nouveau mot de passe (min. 6 car.)" minlength="6" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-map-marker-alt"></i> Nouvelle adresse</label>
                <input type="text" name="adresse2" placeholder="Nouvelle adresse de livraison" required>
            </div>

            <button type="submit" class="btn btn-full">Enregistrer les modifications</button>
        </form>
        <div class="back-link"><a href="user.php"><i class="fas fa-arrow-left"></i> Retour</a></div>
    </div>
</div>
</body>
</html>
