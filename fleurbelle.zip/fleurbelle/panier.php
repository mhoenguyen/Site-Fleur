<?php
require_once 'config.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: user.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['ajouter_panier'])) {
    $nomProduit  = trim($_POST['nom_produit'] ?? '');
    $prixProduit = floatval($_POST['prix_produit'] ?? 0);
    $id_utilisateur = $_SESSION['id_utilisateur'];

    if (empty($nomProduit) || $prixProduit <= 0) {
        header("Location: acceuil.php");
        exit();
    }

    $conn = getConnexion();

    // Vérifier le stock
    $stmtStock = $conn->prepare("SELECT stock FROM produit WHERE NomProduit = ?");
    $stmtStock->bind_param("s", $nomProduit);
    $stmtStock->execute();
    $resStock = $stmtStock->get_result();

    if ($resStock->num_rows > 0) {
        $quantite_stock = $resStock->fetch_assoc()['stock'];
        $stmtStock->close();

        if ($quantite_stock > 0) {
            // Vérifier si le produit est déjà dans le panier
            $stmtVerif = $conn->prepare("SELECT id_panier, Quantite FROM panier WHERE id_produit = ? AND id_utilisateur = ?");
            $stmtVerif->bind_param("si", $nomProduit, $id_utilisateur);
            $stmtVerif->execute();
            $resVerif = $stmtVerif->get_result();

            if ($resVerif->num_rows > 0) {
                // Mettre à jour la quantité
                $row = $resVerif->fetch_assoc();
                $nouvelleQte = $row['Quantite'] + 1;
                $nouveauPrix = $prixProduit * $nouvelleQte;

                $stmtUp = $conn->prepare("UPDATE panier SET Quantite = ?, prix = ? WHERE id_produit = ? AND id_utilisateur = ?");
                $stmtUp->bind_param("idsi", $nouvelleQte, $nouveauPrix, $nomProduit, $id_utilisateur);
                $stmtUp->execute();
                $stmtUp->close();
            } else {
                // Ajouter au panier
                $prixTotal = $prixProduit;
                $stmtIns = $conn->prepare("INSERT INTO panier (id_produit, prix, Quantite, id_utilisateur) VALUES (?, ?, 1, ?)");
                $stmtIns->bind_param("sdi", $nomProduit, $prixTotal, $id_utilisateur);
                $stmtIns->execute();
                $stmtIns->close();
            }
            $stmtVerif->close();

            // Décrémenter le stock de 1
            $stmtUpStock = $conn->prepare("UPDATE produit SET stock = stock - 1 WHERE NomProduit = ? AND stock > 0");
            $stmtUpStock->bind_param("s", $nomProduit);
            $stmtUpStock->execute();
            $stmtUpStock->close();

        } else {
            $conn->close();
            header("Location: acceuil.php?error=rupture_stock");
            exit();
        }
    } else {
        $stmtStock->close();
        $conn->close();
        header("Location: acceuil.php?error=produit_introuvable");
        exit();
    }

    $conn->close();
    header("Location: acceuil.php?success=ajout_panier");
    exit();
} else {
    header("Location: acceuil.php");
    exit();
}
