<?php
require_once 'config.php';
$conn = getConnexion();
echo "✅ Connexion réussie à la base de données '<strong>fleur</strong>' sur le serveur '<strong>localhost</strong>'.";
$conn->close();
