<?php
require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom  = trim($_POST['nom'] ?? '');
    $mail = trim($_POST['mail'] ?? '');
    $tel  = trim($_POST['phone'] ?? '');
    $mess = trim($_POST['mess'] ?? '');

    if (empty($nom) || empty($mail) || empty($mess)) {
        header("Location: acceuil.php?error=contact_incomplet#contact");
        exit();
    }

    $conn = getConnexion();
    $stmt = $conn->prepare("INSERT INTO commentaire (nom, email, numero, Message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nom, $mail, $tel, $mess);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        header("Location: acceuil.php?success=message_envoye#contact");
        exit();
    } else {
        $stmt->close();
        $conn->close();
        header("Location: acceuil.php?error=erreur_contact#contact");
        exit();
    }
} else {
    header("Location: acceuil.php#contact");
    exit();
}
