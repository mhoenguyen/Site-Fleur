<?php
require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        header("Location: user.php?error=champs_vides");
        exit();
    }

    $conn = getConnexion();

    // Prepared statement — protection SQL injection
    $stmt = $conn->prepare("SELECT id_utilisateur, nom, mdp FROM utilisateur WHERE nom = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        // Vérification du mot de passe hashé
        if (password_verify($password, $row['mdp'])) {
            $_SESSION['id_utilisateur']  = $row['id_utilisateur'];
            $_SESSION['nom_utilisateur'] = $row['nom'];
            $stmt->close();
            $conn->close();
            header("Location: acceuil.php");
            exit();
        } else {
            // Compatibilité avec anciens comptes non hashés (plain text)
            if ($password === $row['mdp']) {
                // Mettre à jour vers hash sécurisé
                $newHash = password_hash($password, PASSWORD_DEFAULT);
                $stmtUp = $conn->prepare("UPDATE utilisateur SET mdp = ? WHERE id_utilisateur = ?");
                $stmtUp->bind_param("si", $newHash, $row['id_utilisateur']);
                $stmtUp->execute();
                $stmtUp->close();

                $_SESSION['id_utilisateur']  = $row['id_utilisateur'];
                $_SESSION['nom_utilisateur'] = $row['nom'];
                $stmt->close();
                $conn->close();
                header("Location: acceuil.php");
                exit();
            }
            header("Location: user.php?error=mdp_incorrect");
            exit();
        }
    } else {
        header("Location: user.php?error=utilisateur_introuvable");
        exit();
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: user.php");
    exit();
}
