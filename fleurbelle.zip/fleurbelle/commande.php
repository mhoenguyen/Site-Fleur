<?php
require_once 'config.php';

if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: user.php");
    exit();
}
$id_utilisateur = $_SESSION['id_utilisateur'];

$conn = getConnexion();

$stmt = $conn->prepare("SELECT id_produit, Quantite, prix FROM panier WHERE id_utilisateur = ?");
$stmt->bind_param("i", $id_utilisateur);
$stmt->execute();
$resultat = $stmt->get_result();
$stmt->close();

if ($resultat->num_rows > 0) {
    $conn->begin_transaction();
    try {
        while ($row = $resultat->fetch_assoc()) {
            $id_produit = $row['id_produit'];
            $quantite   = intval($row['Quantite']);
            $prix       = floatval($row['prix']);

            $stmtIns = $conn->prepare("INSERT INTO commande (produit, Quantite, id_utilisateur, date_commande, prix) VALUES (?, ?, ?, NOW(), ?)");
            $stmtIns->bind_param("siid", $id_produit, $quantite, $id_utilisateur, $prix);
            $stmtIns->execute();
            $stmtIns->close();

            $stmtDel = $conn->prepare("DELETE FROM panier WHERE id_utilisateur = ? AND id_produit = ?");
            $stmtDel->bind_param("is", $id_utilisateur, $id_produit);
            $stmtDel->execute();
            $stmtDel->close();
        }
        $conn->commit();
        $conn->close();
        header("Location: resume.php");
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        $conn->close();
        die("Une erreur s'est produite : " . htmlspecialchars($e->getMessage()));
    }
} else {
    $conn->close();
    header("Location: affichage_panier.php");
    exit();
}
