<?php
require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"] ?? '');
    $password = trim($_POST["password"] ?? '');
    $adresse  = trim($_POST["adresse"] ?? '');
    $email    = trim($_POST["email"] ?? '');

    if (empty($username) || empty($password) || empty($adresse)) {
        header("Location: inscreption.php?error=champs_vides");
        exit();
    }

    if (strlen($password) < 6) {
        header("Location: inscreption.php?error=mdp_court");
        exit();
    }

    $conn = getConnexion();

    // Vérifier si le nom est déjà pris
    $stmtCheck = $conn->prepare("SELECT id_utilisateur FROM utilisateur WHERE nom = ?");
    $stmtCheck->bind_param("s", $username);
    $stmtCheck->execute();
    $stmtCheck->store_result();
    if ($stmtCheck->num_rows > 0) {
        $stmtCheck->close();
        $conn->close();
        header("Location: inscreption.php?error=nom_pris");
        exit();
    }
    $stmtCheck->close();

    // Hash du mot de passe
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO utilisateur (nom, mdp, adresse, email) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $hashedPassword, $adresse, $email);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        header("Location: user.php?msg=inscription");
        exit();
    } else {
        $stmt->close();
        $conn->close();
        header("Location: inscreption.php?error=erreur_bd");
        exit();
    }
} else {
    header("Location: inscreption.php");
    exit();
}
