<?php require_once 'config.php';
if (!isset($_SESSION['id_utilisateur'])) {
    header("Location: user.php"); exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FleurBelle – Supprimer mon compte</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: rgb(255, 234, 247); padding-top: 100px; }
        .auth-container { max-width: 450px; margin: 40px auto; padding: 0 20px; }
        .auth-card { background: #fff; border-radius: 12px; padding: 35px 40px; box-shadow: 0 5px 20px rgba(0,0,0,.1); }
        .auth-card h2 { font-size: 2.2rem; color: #e74c3c; margin-bottom: 10px; text-align: center; }
        .warning-box { background: #fff3cd; border: 1px solid #ffc107; border-radius: 8px; padding: 15px; margin-bottom: 20px; font-size: 1.4rem; color: #856404; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 1.4rem; color: #555; margin-bottom: 5px; }
        .form-group input { width: 100%; padding: 11px 14px; border: 1px solid #ddd; border-radius: 8px; font-size: 1.5rem; box-sizing: border-box; }
        .btn-danger { background: #e74c3c; width: 100%; text-align: center; font-size: 1.6rem; margin-top: 10px; }
        .btn-danger:hover { background: #c0392b; }
        .back-link { text-align: center; margin-top: 15px; font-size: 1.4rem; }
        .back-link a { color: var(--pink); }
    </style>
</head>
<body>
<header>
    <a href="acceuil.php" class="logo">FleurBelle <span>.</span></a>
    <div class="icons">
        <a href="acceuil.php"><i class="fas fa-home"></i> Home</a>
        <a href="user.php"><i class="fas fa-user"></i> Mon compte</a>
    </div>
</header>

<div class="auth-container">
    <div class="auth-card">
        <h2><i class="fas fa-trash-alt"></i> Supprimer le compte</h2>
        <div class="warning-box">
            <i class="fas fa-exclamation-triangle"></i>
            <strong>Attention !</strong> Cette action est irréversible. Toutes vos données (commandes, panier) seront supprimées.
        </div>
        <form action="supprimer_utilisateur.php" method="post">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Nom d'utilisateur</label>
                <input type="text" name="username" value="<?= htmlspecialchars($_SESSION['nom_utilisateur'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Mot de passe</label>
                <input type="password" name="password" placeholder="Confirmez avec votre mot de passe" required>
            </div>
            <button type="submit" class="btn btn-danger"
                onclick="return confirm('Êtes-vous sûr de vouloir supprimer votre compte ?')">
                <i class="fas fa-trash"></i> Supprimer définitivement
            </button>
        </form>
        <div class="back-link"><a href="user.php"><i class="fas fa-arrow-left"></i> Annuler</a></div>
    </div>
</div>
</body>
</html>
